from .entities.User import User

class ModelUser():

    @classmethod
    def login(self, conexion, user):
        try:
            #allowed_chars = set(("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_-"))
            cursor = conexion.connection.cursor()
            sql = "SELECT id_usuario, username, password, fullname FROM usuarios WHERE username = '{}'".format(user.username)
            cursor.execute(sql)
            row = cursor.fetchone()
            #validation = set((user.username))
            #if validation.issubset(allowed_chars):
            if row != None:
                user=User(row[0], row[1], User.check_password(row[2], user.password), row[3])
                return user
            else:
                return None
        except Exception as e:
            raise Exception(e)