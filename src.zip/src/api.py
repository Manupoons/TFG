from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_mysqldb import MySQL
from flask_session import Session
from flask_mail import Mail, Message
from werkzeug.security import check_password_hash
from config import config
from datetime import datetime
from authlib.integrations.flask_client import OAuth
import string
import random
time = datetime.now()

current_date = time.strftime("%Y-%m-%d")
current_time = time.strftime("%H:%M:%S")                             

from models.ModelUser import ModelUser
from models.entities.User import User

app = Flask(__name__)

app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'cajerosAPI@gmail.com'
app.config['MAIL_PASSWORD'] = 'zjypldjtlkgatgnb'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
mail = Mail(app)



Session(app)
db = MySQL(app)

oauth = OAuth(app)
GOOGLE_CLIENT_ID = '349275293149-ilrvkrneknja3b4av3dmpudmnffu83n7.apps.googleusercontent.com'
GOOGLE_CLIENT_SECRET = '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'

CONF_URL = 'https://accounts.google.com/.well-known/openid-configuration'
oauth.register(
    name='google',
    client_id=GOOGLE_CLIENT_ID,
    client_secret=GOOGLE_CLIENT_SECRET,
    server_metadata_url=CONF_URL,
    client_kwargs={
        'scope': 'openid email profile'
    }
)

#Variables de configuracion de caracteres validos
allowed_chars = set(("abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ "))
allowed_chars_2 = set(("1234567890abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ "))
allowed_chars_3 = set(("-0123456789"))

def codigo_rnd(length):
    # choose from all lowercase letter
    letters = string.ascii_lowercase
    return( ''.join(random.choice(letters) for i in range(length)))

#Ruta inicial, carga la página de login
@app.route('/', methods=['GET', 'POST'])
def index():
    return render_template('auth/login.html')


#Conectarse a Google para el logueo
@app.route('/google/')
def google():
    redirect_uri = url_for('google_login', _external=True)
    return oauth.google.authorize_redirect(redirect_uri)


#Conectarse a Google para el registro
@app.route('/registro_google/')
def registro_google():
    redirect_uri = url_for('google_register', _external=True)
    return oauth.google.authorize_redirect(redirect_uri)


#Loguearse con Google
@app.route('/google/login/')
def google_login():
    token = oauth.google.authorize_access_token()
    user = oauth.google.parse_id_token(token, nonce=None)
    cursor = db.connection.cursor()
    sql= "SELECT * FROM usuarios WHERE correo='{}'".format(user['email'])
    cursor.execute(sql)
    data = cursor.fetchone()
    session['username'] = data[1]
    return redirect(url_for('listar_cajeros', id_usuario=data[0]))


#Registrarse con Google
@app.route('/google/register/')
def google_register():
    token = oauth.google.authorize_access_token()
    user = oauth.google.parse_id_token(token, nonce=None)
    cursor = db.connection.cursor()
    sql = "SELECT correo FROM usuarios WHERE correo='{}'".format(user['email'])
    cursor.execute(sql)
    data = cursor.fetchone()
    if data is None:
        cursor = db.connection.cursor()
        sql= "INSERT INTO `usuarios`(`username`, `fullname`, `correo`) VALUES ('{}','{}','{}')".format(user['given_name'], user['name'], user['email'])
        cursor.execute(sql)
        db.connection.commit()
        msg = Message('Registro', sender = 'cajerosapi@gmail.com', recipients = [user['email']])
        msg.body = "Te has registrado correctamente, gracias por usar esta aplicación."
        mail.send(msg)
        return redirect(url_for('login'))
    else:
        return redirect(url_for('index'))


#Comprobación de los datos ingresados por el usuario para loguearse
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User(0, request.form['username'], request.form['password'])
        logged_user = ModelUser.login(db, user)
        cursor = db.connection.cursor()
        sql = "SELECT password FROM usuarios WHERE username='{}'".format(request.form['username'])
        cursor.execute(sql)
        data = cursor.fetchone()
        for x in data:
            password = x
        if request.form['username'] != '' and request.form['password'] != '':
            if logged_user != None:
                if password == '':
                    flash('Este usuario se ha registado con Google, debe iniciar sesión con Google')
                    return render_template('auth/login.html', nombre=request.form['username'])
                elif logged_user.password:
                    session['username'] = request.form['username']
                    cursor = db.connection.cursor()
                    sql="SELECT id_usuario, correo FROM usuarios WHERE username= '{}'".format(request.form['username'])
                    cursor.execute(sql)
                    data = cursor.fetchall()
                    for x in data:
                        valor=x[0]
                        #email=x[1]
                    return redirect(url_for('listar_cajeros', id_usuario=valor))
                else:
                    flash('Contraseña incorrecta')
                    return render_template('auth/login.html', nombre=request.form['username'])
            else:
                flash('Usuario no encontrado')
                return render_template('auth/login.html', nombre=request.form['username'])
        else:
            flash('Rellena todos los campos')
            return render_template('auth/login.html', nombre=request.form['username'])
    else:
        return render_template('auth/login.html')


#Función para cerrar la sesión
@app.route('/logout', methods=['POST', 'GET'])
def logout():
    if request.method == 'POST':
        session.clear()
        return redirect(url_for('login'))


#Función intermedia para poder recuperar la contraseña
@app.route('/email_password', methods=['POST', 'GET'])
def email_password():
    if request.method == 'POST':
        if request.form['correo'] != '':
            cursor = db.connection.cursor()
            sql = "SELECT correo FROM usuarios where correo='{}'".format(request.form['correo'])
            cursor.execute(sql)
            data = cursor.fetchone()
            print(data[0])
            if data is not None:
                cursor = db.connection.cursor()
                sql = "SELECT password FROM usuarios where correo='{}'".format(data[0])
                cursor.execute(sql)
                valor = cursor.fetchone()    
                print(valor)
                if valor == '':
                    cursor = db.connection.cursor() 
                    sql="SELECT id_usuario FROM usuarios where correo='{}'".format(request.form['correo'])
                    cursor.execute(sql)
                    data = cursor.fetchone()
                    for x in data:
                        id_usuario = x
                    session['codigo'] = codigo_rnd(10)
                    msg = Message('Recuperar contraseña', sender = 'cajerosapi@gmail.com', recipients = [request.form['correo']])
                    msg.body = "Este es tu código: "+ session['codigo']
                    mail.send(msg)
                    return redirect(url_for('codigo_password', id_usuario=id_usuario))
                else:
                    flash('Este correo pertenece a una cuenta de Google para recuperar la contraseña debe pasar por google')
                    return render_template('auth/editar/email_password.html', correo=request.form['correo'])
            else:
                flash('Este correo no está registrado')
                return render_template('auth/editar/email_password.html', correo=request.form['correo'])    
        else:
            flash('Debe introducir un correo eletrónico para poder continuar')
            return render_template('auth/editar/email_password.html')    
    else:
        return render_template('auth/editar/email_password.html')


#Función para comprobar el código de recuperar contraseña
@app.route('/codigo_password/<id_usuario>', methods=['POST', 'GET'])
def codigo_password(id_usuario):
    if request.method == 'POST':
        if request.form['codigo'] != '':
            if session['codigo'] == request.form['codigo']:
                return redirect(url_for('recuperar_password', id_usuario=id_usuario))
            else:
                flash('El código no es correcto')
                return render_template('auth/editar/codigo_password.html', id_usuario=id_usuario)
        else:
            flash('Debes introducir el código que ha recibido a su correo')
            return render_template('auth/editar/codigo_password.html', id_usuario=id_usuario)
    else:
        return render_template('auth/editar/codigo_password.html', id_usuario=id_usuario)


#Función para recuperar la contraseña
@app.route('/recuperar_password/<id_usuario>', methods=['POST', 'GET'])
def recuperar_password(id_usuario):
    if request.method == 'POST':
        contraseña = User.generate_password_hash(request.form['contraseña'])
        if request.form['contraseña'] != '' and request.form['contraseña1'] != '':
            if request.form['contraseña'] == request.form['contraseña1']:
                cursor = db.connection.cursor()
                sql = "UPDATE usuarios SET password='{}' WHERE id_usuario={}".format(contraseña, id_usuario)
                cursor.execute(sql)
                db.connection.commit()
                return redirect(url_for('login'))
            else:
                flash('Las contraseñas deben coincidir')
                return render_template('auth/editar/recuperar_password.html', id_usuario=id_usuario)
        else:
            flash('Los dos campos deben estar rellenados')
            return render_template('auth/editar/recuperar_password.html', id_usuario=id_usuario)
    else:
        return render_template('auth/editar/recuperar_password.html', id_usuario=id_usuario)


#Comprobación correo antes del registro
@app.route('/emailreg', methods=['GET', 'POST'])
def emailreg():
    if request.method == 'POST':
        cursor = db.connection.cursor()
        sql = "SELECT correo FROM usuarios WHERE correo='{}'".format(request.form['correo'])
        cursor.execute(sql)
        data = cursor.fetchone()
        if data is None:
            return render_template('auth/registros/user_register.html', correo=request.form['correo'])
        else:
            flash('Este correo ya está registrado')
            return render_template('auth/registros/correo_register.html', correo=request.form['correo'])    
    else:
        return render_template('auth/registros/correo_register.html')


#Formulario de registro de usuarios
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        cursor = db.connection.cursor()
        sql="SELECT username FROM usuarios WHERE username='{}'".format(request.form['username'])
        cursor.execute(sql)
        nombre = cursor.fetchone()
        sql1="SELECT correo FROM usuarios WHERE correo='{}'".format(request.form['correo'])
        cursor.execute(sql1)
        correo = cursor.fetchone()
        
        username = request.form['username']
        password = User.generate_password_hash(request.form['password'])
        password1 = User.generate_password_hash(request.form['password1'])
        fullname = request.form['fullname']
        telefono = request.form['telefono']
        email = request.form['correo']

        validation = set((fullname))
        validation2 = set((username))
        if nombre is None:
            if correo is None:
                if validation.issubset(allowed_chars) and validation2.issubset(allowed_chars_2):
                    if request.form['username'] != '' and request.form['password'] != '' and request.form['password1'] != '' and request.form['fullname'] != '':
                        if request.form['password'] == request.form['password1']:
                            cursor = db.connection.cursor()
                            sql = "INSERT INTO `usuarios` (`username`, `fullname`, `telefono`, `correo`, `password`) VALUES ('{}','{}','{}','{}','{}')".format(username, fullname, telefono, email, password)
                            cursor.execute(sql)
                            db.connection.commit()
                            msg = Message('Registro', sender = 'cajerosapi@gmail.com', recipients = [email])
                            msg.body = "Te has registrado correctamente, gracias por usar esta aplicación."
                            mail.send(msg)
                            return redirect(url_for('login'))
                        else:
                            flash('Las contraseñas deben coincidir')
                            return render_template('auth/registros/user_register.html', fullname=request.form['fullname'], username=request.form['username'], telefono=request.form['telefono'], correo=request.form['correo'])
                    else:
                        flash('Rellena todos los campos')
                        return render_template('auth/registros/user_register.html', fullname=request.form['fullname'], username=request.form['username'], telefono=request.form['telefono'], correo=request.form['correo'])
                else:
                    flash('Ni el nombre ni el nombre de usario pueden contener carácteres especiales')
                    return render_template('auth/registros/user_register.html', fullname=request.form['fullname'], username=request.form['username'], telefono=request.form['telefono'], correo=request.form['correo'])
            else:
                flash('Este correo ya está en uso')
                return render_template('auth/registros/user_register.html', fullname=request.form['fullname'], username=request.form['username'], telefono=request.form['telefono'], correo=request.form['correo'])    
        else:
            flash('Este nombre de usuario ya está registrado')
            return render_template('auth/registros/user_register.html', fullname=request.form['fullname'], username=request.form['username'], telefono=request.form['telefono'], correo=request.form['correo'])
    else:
        return render_template('auth/registros/user_register.html')


#Función para listar los datos del usuario logueado
@app.route('/listado_usuario/<id_usuario>', methods=['GET', 'POST'])
def listado_usuario(id_usuario):
    try:
        cursor=db.connection.cursor()
        sql="SELECT * FROM usuarios WHERE id_usuario= {}".format(id_usuario)
        cursor.execute(sql)
        datos=cursor.fetchall()
        usuarios=[]
        for fila in datos:
            fullname=fila[3]
            username=fila[1]
            telefono=fila[4]
            correo=fila[5]
            usuario={'fullname': fullname, 'username': username, 'telefono': telefono, 'correo': correo}
            usuarios.append(usuario)
        return render_template('auth/listados/listado_usuario.html', id_usuario=id_usuario, usuario=usuarios, username = session['username'])
    except Exception as e:
        return render_template('auth/errores/error_listar_usuario.html', id_usuario=id_usuario)


#Función para editar el usuario registrado
@app.route('/editar_usuario/<id_usuario>', methods=['GET', 'POST'])
def editar_usuario(id_usuario):
    if request.method == 'POST':
        cursor = db.connection.cursor()
        sql="SELECT username FROM usuarios WHERE username='{}'".format(request.form['username'])
        cursor.execute(sql)
        nombre = cursor.fetchone()
        sql1="SELECT correo FROM usuarios WHERE correo='{}'".format(request.form['correo'])
        cursor.execute(sql1)
        correo = cursor.fetchone()
        
        if nombre is None:
            if correo is None:
                validation=set((request.form['username']))
                if validation.issubset(allowed_chars_2):
                    if request.form['username']!= '' and request.form['telefono']!= '' and request.form['correo']!= '':               
                        cursor = db.connection.cursor()
                        sql = "UPDATE `usuarios` SET `username`='{}',`telefono`='{}',`correo`='{}' WHERE id_usuario = {}".format(request.form['username'], request.form['telefono'], request.form['correo'], id_usuario)
                        cursor.execute(sql)
                        db.connection.commit()
                        return redirect(url_for('listado_usuario', id_usuario=id_usuario))
                    elif request.form['username']!= '' and request.form['telefono']== '' and request.form['correo']== '':
                        cursor = db.connection.cursor()
                        sql = "UPDATE `usuarios` SET `username`='{}' WHERE id_usuario = {}".format(request.form['username'], id_usuario)
                        cursor.execute(sql)
                        db.connection.commit()
                        return redirect(url_for('listado_usuario', id_usuario=id_usuario))
                    elif request.form['username']== '' and request.form['telefono']!= '' and request.form['correo']== '':
                        cursor = db.connection.cursor()
                        sql = "UPDATE `usuarios` SET `telefono`='{}' WHERE id_usuario = {}".format(request.form['telefono'], id_usuario)
                        cursor.execute(sql)
                        db.connection.commit()
                        return redirect(url_for('listado_usuario', id_usuario=id_usuario))
                    elif request.form['username']== '' and request.form['telefono']== '' and request.form['correo']!= '':
                        cursor = db.connection.cursor()
                        sql = "UPDATE `usuarios` SET `correo`='{}' WHERE id_usuario = {}".format(request.form['correo'], id_usuario)
                        cursor.execute(sql)
                        db.connection.commit()
                        return redirect(url_for('listado_usuario', id_usuario=id_usuario))
                    elif request.form['username']!= '' and request.form['telefono']!= '' and request.form['correo']== '':
                        cursor = db.connection.cursor()
                        sql = "UPDATE `usuarios` SET `username`='{}',`telefono`='{}' WHERE id_usuario = {}".format(request.form['username'], request.form['telefono'], id_usuario)
                        cursor.execute(sql)
                        db.connection.commit()
                        return redirect(url_for('listado_usuario', id_usuario=id_usuario))
                    elif request.form['username']!= '' and request.form['telefono']== '' and request.form['correo']!= '':
                        cursor = db.connection.cursor()
                        sql = "UPDATE `usuarios` SET `username`='{}',`correo`='{}' WHERE id_usuario = {}".format(request.form['username'], request.form['correo'], id_usuario)
                        cursor.execute(sql)
                        db.connection.commit()
                        return redirect(url_for('listado_usuario', id_usuario=id_usuario))
                    elif request.form['username']== '' and request.form['telefono']!= '' and request.form['correo']!= '':
                        cursor = db.connection.cursor()
                        sql = "UPDATE `usuarios` SET `telefono`='{}', `correo`='{}' WHERE id_usuario = {}".format(request.form['telefono'], request.form['correo'], id_usuario)
                        cursor.execute(sql)
                        db.connection.commit()
                        return redirect(url_for('listado_usuario', id_usuario=id_usuario))
                    else:
                        flash('Rellena al menos un campo')
                        return render_template('auth/editar/editar_usuario.html', id_usuario=id_usuario, username=request.form['username'], telefono=request.form['telefono'], correo=request.form['correo'])
                else:
                    flash('El nombre de usuario no puede contener carácteres especiales')
                    return render_template('auth/editar/editar_usuario.html', id_usuario=id_usuario, username=request.form['username'], telefono=request.form['telefono'], correo=request.form['correo'])
            else:
                flash('Este correo ya existe')
                return render_template('auth/editar/editar_usuario.html', id_usuario=id_usuario, username=request.form['username'], telefono=request.form['telefono'], correo=request.form['correo'])
        else:
            flash('Este nombre de usuario ya existe')
            return render_template('auth/editar/editar_usuario.html', id_usuario=id_usuario, username=request.form['username'], telefono=request.form['telefono'], correo=request.form['correo'])
    else:
        return render_template('auth/editar/editar_usuario.html', id_usuario=id_usuario)    


#Función para cambiar la contraseña del usuario registrado
@app.route('/cambiar_password/<id_usuario>', methods=['GET', 'POST'])
def cambiar_password(id_usuario):
    cursor = db.connection.cursor()
    sql = "SELECT password FROM usuarios WHERE id_usuario = {}".format(id_usuario)
    cursor.execute(sql)
    password = cursor.fetchone()
    for x in password:
        valor = x
    if request.method == 'POST':
        if request.form['password'] != '' and request.form['password1'] != '' and request.form['password2'] != '':
            if check_password_hash(valor, request.form['password']) and request.form['password'] != request.form['password1'] and request.form['password1'] == request.form['password2']:
                try:
                    contraseña = User.generate_password_hash(request.form['password2'])
                    cursor = db.connection.cursor()
                    sql = "UPDATE `usuarios` SET `password`='{}' WHERE id_usuario = {}".format(contraseña, id_usuario)
                    cursor.execute(sql)
                    db.connection.commit()
                    return redirect(url_for('listado_usuario', id_usuario=id_usuario))
                except Exception as e:
                    return render_template('auth/errores/error_cambiar_password.html', id_usuario=id_usuario)
            else:
                flash('Las contraseñas no coinciden')
                return render_template('auth/editar/cambiar_password.html', id_usuario=id_usuario, password1=request.form['password1'], password2=request.form['password2'], password=request.form['password'])
        else:
            flash('Debes rellenar todos los campos')
            return render_template('auth/editar/cambiar_password.html', id_usuario=id_usuario, password1=request.form['password1'], password2=request.form['password2'], password=request.form['password'])
    else:
        return render_template('auth/editar/cambiar_password.html', id_usuario=id_usuario)


#Formulario de registro de cajeros
@app.route('/rcajeros/<id_usuario>', methods=['GET', 'POST'])
def nuevo_cajero(id_usuario):
    if request.method == 'POST':
        cursor = db.connection.cursor()
        sql = "SELECT Num_Serie FROM `cajeros` WHERE Num_Serie = '{}'".format(request.form['num_serie'])
        cursor.execute(sql)
        datos=cursor.fetchone()
        validation = set((request.form['localidad']))
        validation1 = set((request.form['num_serie']))
        if datos is not None:
            flash('El cajero con este número de serie ya está registrado')
            return render_template('auth/registros/cajero_register.html')
        else:
            if request.form['num_serie'] != '' and request.form['localidad'] != '' and request.form['estado']:
                if validation.issubset(allowed_chars) and validation1.issubset(allowed_chars_2):
                    cursor = db.connection.cursor()  
                    sql = "INSERT INTO `cajeros`(`Num_Serie`, `Lugar`, `Estado`, `id_usuario`) VALUES ('{}','{}',{}, {})".format(request.form['num_serie'], request.form['localidad'], request.form['estado'], id_usuario)
                    cursor.execute(sql)
                    db.connection.commit()
                    return redirect(url_for('listar_cajeros', id_usuario=id_usuario))
                else:
                    flash('Ningú dato puede contener caracteres especiales')
                    return render_template('auth/registros/cajero_register.html', id_usuario=id_usuario, num_serie=request.form['num_serie'], localidad=request.form['localidad'], estado=request.form['estado'])
            else:
                flash('Rellena todos los campos')
                return render_template('auth/registros/cajero_register.html', id_usuario=id_usuario, num_serie=request.form['num_serie'], localidad=request.form['localidad'], estado=request.form['estado'])
    else:
        return render_template('auth/registros/cajero_register.html', id_usuario=id_usuario)


#Función para cargar el listado de cajeros  
@app.route('/cajeros/<id_usuario>', methods=['GET', 'POST'])
def listar_cajeros(id_usuario):
    try:
        cursor=db.connection.cursor()
        sql="SELECT * FROM cajeros WHERE id_usuario = {} AND cajero_eliminado = 0".format(id_usuario)
        cursor.execute(sql)
        datos=cursor.fetchall()
        cajeros=[]
        for fila in datos:
            id_cajero=fila[0]
            Num_Serie=fila[1]
            Lugar=fila[2]
            Estado=fila[3]
            if Estado==1:
                Estado='Activo'
            elif Estado==0:
                Estado='Inactivo'
            cajero={'id_cajero': id_cajero, 'Num_Serie': Num_Serie, 'Lugar': Lugar, 'Estado': Estado}
            cajeros.append(cajero)
        return render_template('auth/listados/listado_cajeros.html', id_usuario=id_usuario, cajero=cajeros, usuario = session['username'])
    except Exception as e:
        return render_template('auth/errores/error_listado.html')
    
@app.route('/listado_pdf_cajeros/<id_usuario>', methods=['GET', 'POST'])
def cajeros_pdf(id_usuario):
    try:
        cursor=db.connection.cursor()
        sql="SELECT * FROM cajeros WHERE id_usuario = {} AND cajero_eliminado = 0".format(id_usuario)
        cursor.execute(sql)
        datos=cursor.fetchall()
        cajeros=[]
        for fila in datos:
            id_cajero=fila[0]
            Num_Serie=fila[1]
            Lugar=fila[2]
            Estado=fila[3]
            if Estado==1:
                Estado='Activo'
            elif Estado==0:
                Estado='Inactivo'
            cajero={'id_cajero': id_cajero, 'Num_Serie': Num_Serie, 'Lugar': Lugar, 'Estado': Estado}
            cajeros.append(cajero)
        return render_template('auth/listados/listado_pdf_cajeros.html', id_usuario=id_usuario, cajero=cajeros, usuario = session['username'])
    except Exception as e:
        return render_template('auth/errores/error_listado.html')

#Función para editar un cajero
@app.route('/editcajeros/<id_cajero>', methods=['GET', 'POST'])
def edit_cajero(id_cajero):
    cursor = db.connection.cursor()
    sql = "SELECT id_usuario FROM cajeros WHERE id_cajero={}".format(id_cajero)
    cursor.execute(sql)
    id_usuario = cursor.fetchone()
    for x in id_usuario:
        valor=x 
    if request.method == 'POST':   
        validation = set((request.form['localidad']))
        if validation.issubset(allowed_chars):
            if request.form['localidad'] == '' and request.form['estado'] != '':
                cursor = db.connection.cursor()
                sql = "SELECT Lugar FROM cajeros WHERE id_cajero={}".format(id_cajero)
                request.form['localidad'] == sql
                try:
                    cursor = db.connection.cursor()
                    sql = "UPDATE `cajeros` SET `Estado` = {} WHERE id_cajero = {}".format(request.form['estado'], id_cajero)
                    cursor.execute(sql)
                    db.connection.commit()
                    return redirect(url_for('listar_cajeros', id_usuario=valor))
                except Exception as e:
                    return render_template('auth/errores/error_editar.html')
            elif request.form['localidad'] != '' and request.form['estado'] == '':
                cursor = db.connection.cursor()
                sql = "SELECT Estado FROM cajeros WHERE id_cajero={}".format(id_cajero)
                request.form['estado'] == sql
                try:
                    cursor = db.connection.cursor()
                    sql = "UPDATE `cajeros` SET `Lugar` = '{}' WHERE id_cajero = {}".format(request.form['localidad'], id_cajero)
                    cursor.execute(sql)
                    db.connection.commit()
                    return redirect(url_for('listar_cajeros', id_usuario=valor))
                except Exception as e:
                    return render_template('auth/errores/error_editar.html')
            elif request.form['localidad'] != '' and request.form['estado']!= '':
                try:
                    cursor = db.connection.cursor()
                    sql = "UPDATE `cajeros` SET `Lugar` = '{}', `Estado` = {} WHERE id_cajero = {}".format(request.form['localidad'], request.form['estado'], id_cajero)
                    cursor.execute(sql)
                    db.connection.commit()
                    return redirect(url_for('listar_cajeros', id_usuario=valor))
                except Exception as e:
                    return render_template('auth/errores/error_editar.html') 
            else:
                flash('Rellena por lo menos un campo')
                return render_template('auth/editar/editar_cajero.html', id_cajero=id_cajero, id_usuario=valor)
        else:
            flash('La localidad no puede contener caracteres especiales')
            return render_template('auth/editar/editar_cajero.html', id_cajero=id_cajero, id_usuario=valor, ciudad=request.form['localidad'], estado=request.form['estado']) 
    else:
        return render_template('auth/editar/editar_cajero.html', id_cajero=id_cajero, id_usuario=valor)


#Función para eliminar un cajero
@app.route('/elimcajeros/<id_cajero>', methods=['GET', 'POST'])
def borrar_cajero(id_cajero):
    cursor = db.connection.cursor()
    sql = "SELECT id_usuario FROM cajeros WHERE id_cajero={}".format(id_cajero)
    cursor.execute(sql)
    id_usuario = cursor.fetchone()
    for x in id_usuario:
        valor=x
    try:
        cursor = db.connection.cursor()
        sql = "UPDATE `cajeros` SET `cajero_eliminado`= 1 WHERE id_cajero = {}".format(id_cajero)
        cursor.execute(sql)
        db.connection.commit()
        return redirect(url_for('listar_cajeros', id_usuario=valor))
    except Exception as e:
        return render_template('auth/errores/error_eliminar.html')


#Función para listar las transacciones de un cajero
@app.route('/transacciones/<id_cajero>', methods=['GET', 'POST'])
def listar_transacciones(id_cajero):
    cursor = db.connection.cursor()
    sql="SELECT id_usuario FROM cajeros WHERE id_cajero = {}".format(id_cajero)
    cursor.execute(sql)
    id_usuario=cursor.fetchone()
    for x in id_usuario:
        valor=x
    try:
        cursor=db.connection.cursor()
        sql="SELECT * FROM transacciones WHERE id_cajero = '{}' AND transac_eliminada = 0".format(id_cajero)
        cursor.execute(sql)
        datos=cursor.fetchall()
        transacciones=[]
        for fila in datos:
            id_transaccion=fila[0]
            nombre=fila[1]
            dinero=fila[2]
            tarjeta=fila[3]
            fecha=fila[4]
            transaccion={'id_transaccion': id_transaccion, 'nombre': nombre, 'dinero': dinero, 'tarjeta': tarjeta, 'fecha': fecha}
            transacciones.append(transaccion)
        return render_template('auth/listados/listado_transacciones.html', id_cajero=id_cajero, transaccion=transacciones, id_usuario=valor, usuario = session['username'], hora=current_time)
    except Exception as e:
        return render_template('auth/errores/error_list_trans.html', id_usuario=valor)


#Función para crear una transacción
@app.route('/crear_transacciones/<id_cajero>', methods=['GET', 'POST'])
def crear_transaccion(id_cajero):
    if request.method == 'POST':
        validation = set((request.form['nombre']))
        validation1 = set((request.form['dinero']))
        validation2 = set((request.form['tarjeta']))
        if validation.issubset(allowed_chars):
            if validation1.issubset(allowed_chars_3) and validation2.issubset(allowed_chars_2):
                if request.form['nombre'] != '' and request.form['dinero'] != '' and request.form['tarjeta'] != '' and request.form['fecha'] != '':
                    cursor=db.connection.cursor()
                    sql="INSERT INTO `transacciones`(`Nombre`, `Dinero`, `Tarjeta`, `Fecha`, `id_cajero`) VALUES ('{}','{}','{}','{}','{}')".format(request.form['nombre'], request.form['dinero'], request.form['tarjeta'], request.form['fecha'], id_cajero)
                    cursor.execute(sql)
                    db.connection.commit()
                    return redirect(url_for('listar_transacciones', id_cajero=id_cajero))
                else:
                    flash('Rellena todos los campos')
                    return render_template('auth/registros/transaccion_register.html', cajero=id_cajero, nombre=request.form['nombre'], dinero=request.form['dinero'], tarjeta=request.form['tarjeta'], fecha=request.form['fecha'], fecha_max=current_date)
            else:
                flash('Ni el dinero ni la cuenta pueden contener caracteres especiales')
                return render_template('auth/registros/transaccion_register.html', cajero=id_cajero, nombre=request.form['nombre'], dinero=request.form['dinero'], tarjeta=request.form['tarjeta'], fecha=request.form['fecha'], fecha_max=current_date)
        else:
            flash('El nombre no puede contener caracteres especiales')
            return render_template('auth/registros/transaccion_register.html', cajero=id_cajero, nombre=request.form['nombre'], dinero=request.form['dinero'], tarjeta=request.form['tarjeta'], fecha=request.form['fecha'], fecha_max=current_date)
    else:
        return render_template('auth/registros/transaccion_register.html', cajero=id_cajero, fecha=current_date, fecha_max=current_date)


#Función para listar los datos del usuario logueado
@app.route('/transacciones_pdf/<id_cajero>', methods=['GET', 'POST'])
def transacciones_pdf(id_cajero):
    cursor = db.connection.cursor()
    sql="SELECT id_usuario FROM cajeros WHERE id_cajero = {}".format(id_cajero)
    cursor.execute(sql)
    id_usuario=cursor.fetchone()
    for x in id_usuario:
        valor=x
    try:
        cursor=db.connection.cursor()
        sql="SELECT * FROM transacciones WHERE id_cajero = '{}' AND transac_eliminada = 0".format(id_cajero)
        cursor.execute(sql)
        datos=cursor.fetchall()
        transacciones=[]
        for fila in datos:
            id_transaccion=fila[0]
            nombre=fila[1]
            dinero=fila[2]
            tarjeta=fila[3]
            fecha=fila[4]
            transaccion={'id_transaccion': id_transaccion, 'nombre': nombre, 'dinero': dinero, 'tarjeta': tarjeta, 'fecha': fecha}
            transacciones.append(transaccion)
        return render_template('auth/listados/listado_pdf_trans.html', id_cajero=id_cajero, transaccion=transacciones, id_usuario=valor, usuario = session['username'])
    except Exception as e:
        return render_template('auth/errores/error_list_trans.html', id_cajero=id_cajero)


#Función para eliminar una transacción
@app.route('/elimtransacciones/<id_transaccion>', methods=['GET', 'POST'])
def eliminar_transaccion(id_transaccion):
    cursor = db.connection.cursor()
    sql="SELECT id_cajero FROM transacciones WHERE id_transaccion = {}".format(id_transaccion)
    cursor.execute(sql)
    cajero=cursor.fetchone()
    for x in cajero:
        valor=x
    try:
        cursor = db.connection.cursor()
        sql = "UPDATE `transacciones` SET `transac_eliminada`= 1 WHERE id_transaccion = {}".format(id_transaccion)
        cursor.execute(sql)
        db.connection.commit()
        return redirect(url_for('listar_transacciones', id_cajero=valor))
    except Exception as e:
        return render_template('auth/errores/error_elim_trans.html', id_cajero=valor)


#En caso de que ocurra algún problema al buscar una página
def error_pagina(error):
    return "<h2>La página que intentas buscar no existe</h2>", 404


#Para correr la app
if __name__ == "__main__":
    app.config.from_object(config['development'])
    app.register_error_handler(404, error_pagina)
    app.run()
